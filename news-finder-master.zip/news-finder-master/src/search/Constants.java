package search;

public class Constants {
	public static String CRAWLER_DEFAULT_URL = "https://bbc.com";

	public static final int CRAWLING_DEPTH = 5;

}
